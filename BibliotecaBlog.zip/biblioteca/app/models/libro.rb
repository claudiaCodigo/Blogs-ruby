class Libro < ApplicationRecord
end
