class CreateLibros < ActiveRecord::Migration[5.1]
  def change
    create_table :libros do |t|
      t.string :titulo
      t.string :subtitulo
      t.string :autor
      t.string :editorial
      t.string :publicacion
      t.string :paginas
      t.integer :visits_count

      t.timestamps
    end
  end
end
