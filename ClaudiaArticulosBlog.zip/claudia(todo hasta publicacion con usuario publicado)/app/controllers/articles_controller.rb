class ArticlesController < ApplicationController


# GET /articles
  def index
    #son todos los registros

    @articles = Article.all
  end

# GET /articles/:id
  def show
    #encontrar registro por id

    @article = Article.find(params[:id])

  end

# GET /articles/new
  def new

    @article = Article.new

  end

# GET /articles/id/edit - 23/10/18
  def edit

    @article = Article.find(params[:id])

  end


# GET /articles/id/update -23/10/18

   def update
     @article = Article.find(params[:id])

if @article.update(article_params)

redirect_to @article

else
  render :edit

end
  end



 #POST /articles
  def create

    @article = current_user.articles.new(article_params)

    if @article.save
    redirect_to @article

  else

    render :new
  end
end


#23/10/18 - Proteccion de datos

private

def article_params

params.require(:article).permit(:title, :body)

end




end
