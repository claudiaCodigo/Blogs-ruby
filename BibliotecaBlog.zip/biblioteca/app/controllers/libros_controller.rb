class LibrosController < ApplicationController


# GET /articles
  def index

    @libros = Libro.all
  end

# GET /articles/:id
  def show

    @libro = Libro.find(params[:id])

  end

# GET /articles/new
  def new

    @libro = Libro.new

  end

  # GET /articles/id/edit - 23/10/18
    def edit

      @libro = Libro.find(params[:id])

    end


  # GET /articles/id/update -23/10/18

     def update
       @libro = Libro.find(params[:id])

  if @libro.update(libro_params) #la variable libro_params viene del controlador declarado hasta abajo que es para validar los datos

  redirect_to @libro

  else
    render :edit

  end
    end


 #POST /articles
  def create

    @libro = Libro.new(titulo: params[:libro][:titulo],  subtitulo: params[:libro][:subtitulo], autor: params[:libro][:autor], editorial: params[:libro][:editorial], publicacion: params[:libro][:publicacion], paginas: params[:libro][:paginas])

    if @libro.save
    redirect_to @libro

  else

    render :new
  end
end

#23/10/18 - Proteccion de datos

private

def libro_params

params.require(:libro).permit(:titulo, :subtitulo, :autor, :editorial, :publicacion, :paginas)

end


end
